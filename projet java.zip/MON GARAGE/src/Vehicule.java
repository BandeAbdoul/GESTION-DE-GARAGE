import java.io.Serializable;

// Classe représentant un véhicule
public class Vehicule implements Serializable {
    private String marque;
    private String modele;
    private int kilometrage;
    private String immatriculation;
    private Client proprietaire;
    private String etatIntervention;

    // Constructeur
    public Vehicule(String marque, String modele, int kilometrage, String immatriculation, Client proprietaire) {
        this.marque = marque;
        this.modele = modele;
        this.kilometrage = kilometrage;
        this.immatriculation = immatriculation;
        this.proprietaire = proprietaire;
        this.etatIntervention = "En cours";
    }

    // Getters et setters
    public String getMarque() {
        return marque;
    }

    public String getModele() {
        return modele;
    }

    public int getKilometrage() {
        return kilometrage;
    }

    public String getImmatriculation() {
        return immatriculation;
    }

    public Client getProprietaire() {
        return proprietaire;
    }

    public String getEtatIntervention() {
        return etatIntervention;
    }

    public void setEtatIntervention(String etatIntervention) {
        this.etatIntervention = etatIntervention;
    }

    // Méthode toString pour afficher les informations du véhicule
    @Override
    public String toString() {
        return "Marque : " + marque + ", Modèle : " + modele + ", Immatriculation : " + immatriculation + ", Propriétaire : " + proprietaire.getNom();
    }
}
