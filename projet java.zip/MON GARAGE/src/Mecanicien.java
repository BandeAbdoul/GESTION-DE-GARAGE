import java.io.Serializable;

// Classe représentant un mécanicien
public class Mecanicien implements Serializable {
    private String nom;
    private String matricule;
    private String statut;

    // Constructeur
    public Mecanicien(String nom, String matricule) {
        this.nom = nom;
        this.matricule = matricule;
        this.statut = "Repos";
    }

    // Getters et setters
    public String getNom() {
        return nom;
    }

    public String getMatricule() {
        return matricule;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    // Méthode toString pour afficher les informations du mécanicien
    @Override
    public String toString() {
        return "Nom : " + nom + ", Matricule : " + matricule + ", Statut : " + statut;
    }
}
