import java.util.Scanner;

public class Main {
    private static Garage garage = new Garage(); // Instance du garage
    private static Scanner scanner = new Scanner(System.in); // Scanner pour les entrées utilisateur

    public static void main(String[] args) {
        // Charger les données du garage au démarrage
        garage.chargerDonnees();

        boolean quitter = false;
        while (!quitter) {
            afficherMenu(); // Afficher le menu principal
            System.out.print("Choisissez une option : ");
            int choix = scanner.nextInt();
            scanner.nextLine(); // Consommer la nouvelle ligne

            switch (choix) {
                case 1:
                    garage.afficherClients();
                    break;
                case 2:
                    garage.afficherVehicules();
                    break;
                case 3:
                    garage.afficherMecaniciens();
                    break;
                case 4:
                    garage.afficherInterventionsEnCours();
                    break;
                case 5:
                    garage.ajouterClient();
                    break;
                case 6:
                    garage.ajouterVehicule();
                    break;
                case 7:
                    garage.ajouterIntervention();
                    break;
                case 8:
                    garage.ajouterMecanicien();
                    break;
                case 9:
                    rechercherClient();
                    break;
                case 10:
                    rechercherVehicule();
                    break;
                case 11:
                    garage.sauvegarderDonnees(); // Sauvegarder les données avant de quitter
                    quitter = true;
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Option invalide, veuillez réessayer.");
            }
        }
    }

    // Méthode pour afficher le menu principal
    private static void afficherMenu() {
        System.out.println("\n--- Menu Principal ---");
        System.out.println("1. Afficher les clients");
        System.out.println("2. Afficher les véhicules");
        System.out.println("3. Afficher les mécaniciens");
        System.out.println("4. Afficher les interventions en cours");
        System.out.println("5. Ajouter un client");
        System.out.println("6. Ajouter un véhicule");
        System.out.println("7. Ajouter une intervention");
        System.out.println("8. Ajouter un mécanicien");
        System.out.println("9. Rechercher un client");
        System.out.println("10. Rechercher un véhicule");
        System.out.println("11. Quitter");
    }

    // Méthode pour rechercher un client par nom
    private static void rechercherClient() {
        System.out.print("Entrez le nom du client : ");
        String nom = scanner.nextLine();
        garage.rechercherClient(nom);
    }

    // Méthode pour rechercher un véhicule par immatriculation
    private static void rechercherVehicule() {
        System.out.print("Entrez l'immatriculation du véhicule : ");
        String immatriculation = scanner.nextLine();
        garage.rechercherVehicule(immatriculation);
    }
}
