import java.io.Serializable;

// Classe représentant une intervention
public class Intervention implements Serializable {
    private String description;
    private String dateDebut;
    private Vehicule vehicule;
    private Mecanicien mecanicien;
    private String statut;

    // Constructeur
    public Intervention(String description, String dateDebut, Vehicule vehicule, Mecanicien mecanicien) {
        this.description = description;
        this.dateDebut = dateDebut;
        this.vehicule = vehicule;
        this.mecanicien = mecanicien;
        this.statut = "En cours";
    }

    // Getters et setters
    public String getDescription() {
        return description;
    }

    public String getDateDebut() {
        return dateDebut;
    }

    public Vehicule getVehicule() {
        return vehicule;
    }

    public Mecanicien getMecanicien() {
        return mecanicien;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    // Méthode toString pour afficher les informations de l'intervention
    @Override
    public String toString() {
        return "Description : " + description + ", Date de début : " + dateDebut + ", Véhicule : " + vehicule.getMarque() + ", Mécanicien : " + mecanicien.getNom();
    }
}
