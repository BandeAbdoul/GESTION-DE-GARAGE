import java.io.Serializable;

// Classe représentant un client
public class Client implements Serializable {
    private String nom;
    private String adresse;
    private String numero;

    // Constructeur
    public Client(String nom, String adresse, String numero) {
        this.nom = nom;
        this.adresse = adresse;
        this.numero = numero;
    }

    // Getters et setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    // Méthode toString pour afficher les informations du client
    @Override
    public String toString() {
        return "Nom : " + nom + ", Adresse : " + adresse + ", Numéro : " + numero;
    }
}
