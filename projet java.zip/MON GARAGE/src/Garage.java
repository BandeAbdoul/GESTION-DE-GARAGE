import java.io.*;
import java.util.*;

public class Garage implements Serializable {
    private List<Client> clients;
    private List<Vehicule> vehicules;
    private List<Mecanicien> mecaniciens;
    private List<Intervention> interventions;

    private transient Scanner scanner; // Transient pour ne pas le sérialiser
    private final String FICHIER_DONNEES = "garage_data.ser"; // Fichier de sauvegarde

    // Constructeur
    public Garage() {
        clients = new ArrayList<>();
        vehicules = new ArrayList<>();
        mecaniciens = new ArrayList<>();
        interventions = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    // Méthode pour charger les données depuis le fichier
    public void chargerDonnees() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FICHIER_DONNEES))) {
            Garage data = (Garage) ois.readObject();
            this.clients = data.clients;
            this.vehicules = data.vehicules;
            this.mecaniciens = data.mecaniciens;
            this.interventions = data.interventions;
            System.out.println("Données chargées avec succès.");
        } catch (FileNotFoundException e) {
            System.out.println("Aucune donnée existante. Nouveau garage créé.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erreur lors du chargement des données.");
            e.printStackTrace();
        }
    }

    // Méthode pour sauvegarder les données dans le fichier
    public void sauvegarderDonnees() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHIER_DONNEES))) {
            oos.writeObject(this);
            System.out.println("Données sauvegardées avec succès.");
        } catch (IOException e) {
            System.out.println("Erreur lors de la sauvegarde des données.");
            e.printStackTrace();
        }
    }

    // Méthode pour afficher les clients
    public void afficherClients() {
        if (clients.isEmpty()) {
            System.out.println("Aucun client à afficher.");
            return;
        }
        for (int i = 0; i < clients.size(); i++) {
            Client client = clients.get(i);
            System.out.println("\n******************************");
            System.out.println((i + 1) + ".");
            System.out.println("Nom : " + client.getNom());
            System.out.println("Adresse : " + client.getAdresse());
            System.out.println("Numéro : " + client.getNumero());
            System.out.println("Liste des véhicules du client :");
            for (Vehicule v : vehicules) {
                if (v.getProprietaire().equals(client)) {
                    System.out.println("\t* " + v.getMarque() + " (Immatriculation : " + v.getImmatriculation() + ")");
                }
            }
            System.out.println("******************************");
        }
        System.out.print("*** Pour modifier un client, entrez son numéro ou tapez # pour revenir au menu : ");
        String choix = scanner.nextLine();
        if (!choix.equals("#")) {
            try {
                int index = Integer.parseInt(choix) - 1;
                modifierClient(index);
            } catch (NumberFormatException | IndexOutOfBoundsException e) {
                System.out.println("Numéro invalide.");
            }
        }
    }

    // Méthode pour modifier un client (exemple simplifié)
    private void modifierClient(int index) {
        Client client = clients.get(index);
        System.out.print("Entrez le nouveau nom (laissez vide pour ne pas changer) : ");
        String nom = scanner.nextLine();
        if (!nom.isEmpty()) {
            client.setNom(nom);
        }
        System.out.print("Entrez la nouvelle adresse (laissez vide pour ne pas changer) : ");
        String adresse = scanner.nextLine();
        if (!adresse.isEmpty()) {
            client.setAdresse(adresse);
        }
        System.out.print("Entrez le nouveau numéro (laissez vide pour ne pas changer) : ");
        String numero = scanner.nextLine();
        if (!numero.isEmpty()) {
            client.setNumero(numero);
        }
        sauvegarderDonnees();
        System.out.println("Client modifié avec succès.");
    }

    // Méthode pour afficher les véhicules
    public void afficherVehicules() {
        if (vehicules.isEmpty()) {
            System.out.println("Aucun véhicule à afficher.");
            return;
        }
        for (int i = 0; i < vehicules.size(); i++) {
            Vehicule v = vehicules.get(i);
            System.out.println("\n****************************");
            System.out.println((i + 1) + ".");
            System.out.println("Marque : " + v.getMarque());
            System.out.println("Modèle : " + v.getModele());
            System.out.println("Immatriculation : " + v.getImmatriculation());
            System.out.println("Kilométrage : " + v.getKilometrage());
            System.out.println("Propriétaire : " + v.getProprietaire().getNom());
            System.out.println("État de l'intervention : " + v.getEtatIntervention());
            System.out.println("****************************");
        }
        System.out.print("*** Pour changer l'état de l'intervention d'un véhicule, entrez son numéro ou tapez # pour revenir au menu : ");
        String choix = scanner.nextLine();
        if (!choix.equals("#")) {
            try {
                int index = Integer.parseInt(choix) - 1;
                changerEtatInterventionVehicule(index);
            } catch (NumberFormatException | IndexOutOfBoundsException e) {
                System.out.println("Numéro invalide.");
            }
        }
    }

    // Méthode pour changer l'état de l'intervention d'un véhicule
    private void changerEtatInterventionVehicule(int index) {
        Vehicule vehicule = vehicules.get(index);
        System.out.println("Choisir l'état de l'intervention :");
        System.out.println("1. En cours");
        System.out.println("2. Terminé");
        System.out.print("Choix : ");
        int choix = scanner.nextInt();
        scanner.nextLine(); // Consommer la nouvelle ligne
        if (choix == 1) {
            vehicule.setEtatIntervention("En cours");
        } else if (choix == 2) {
            vehicule.setEtatIntervention("Terminé");
        } else {
            System.out.println("Choix invalide.");
            return;
        }
        sauvegarderDonnees();
        System.out.println("État de l'intervention mis à jour.");
    }

    // Méthode pour afficher les mécaniciens
    public void afficherMecaniciens() {
        if (mecaniciens.isEmpty()) {
            System.out.println("Aucun mécanicien à afficher.");
            return;
        }
        for (int i = 0; i < mecaniciens.size(); i++) {
            Mecanicien m = mecaniciens.get(i);
            System.out.println("\n******************************");
            System.out.println((i + 1) + ".");
            System.out.println("Nom : " + m.getNom());
            System.out.println("Matricule : " + m.getMatricule());
            System.out.println("Statut : " + m.getStatut());
            System.out.println("******************************");
        }
        System.out.print("*** Pour modifier le statut d'un mécanicien, entrez son numéro ou tapez # pour revenir au menu : ");
        String choix = scanner.nextLine();
        if (!choix.equals("#")) {
            try {
                int index = Integer.parseInt(choix) - 1;
                changerStatutMecanicien(index);
            } catch (NumberFormatException | IndexOutOfBoundsException e) {
                System.out.println("Numéro invalide.");
            }
        }
    }

    // Méthode pour changer le statut d'un mécanicien
    private void changerStatutMecanicien(int index) {
        Mecanicien mecanicien = mecaniciens.get(index);
        System.out.println("Choisir le statut :");
        System.out.println("1. En activité");
        System.out.println("2. Repos");
        System.out.print("Choix : ");
        int choix = scanner.nextInt();
        scanner.nextLine(); // Consommer la nouvelle ligne
        if (choix == 1) {
            mecanicien.setStatut("En activité");
        } else if (choix == 2) {
            mecanicien.setStatut("Repos");
        } else {
            System.out.println("Choix invalide.");
            return;
        }
        sauvegarderDonnees();
        System.out.println("Statut du mécanicien mis à jour.");
    }

    // Méthode pour afficher les interventions en cours
    public void afficherInterventionsEnCours() {
        List<Intervention> interventionsEnCours = new ArrayList<>();
        for (Intervention inter : interventions) {
            if (inter.getStatut().equalsIgnoreCase("En cours")) {
                interventionsEnCours.add(inter);
            }
        }
        if (interventionsEnCours.isEmpty()) {
            System.out.println("Aucune intervention en cours.");
            return;
        }
        for (int i = 0; i < interventionsEnCours.size(); i++) {
            Intervention inter = interventionsEnCours.get(i);
            System.out.println("\n*************************************");
            System.out.println((i + 1) + ".");
            System.out.println("Description : " + inter.getDescription());
            System.out.println("Date de début : " + inter.getDateDebut());
            System.out.println("Mécanicien : " + inter.getMecanicien().getNom() + " (Matricule : " + inter.getMecanicien().getMatricule() + ")");
            System.out.println("Véhicule : " + inter.getVehicule().getMarque() + " (Immatriculation : " + inter.getVehicule().getImmatriculation() + ")");
            System.out.println("Propriétaire : " + inter.getVehicule().getProprietaire().getNom());
            System.out.println("Statut : " + inter.getStatut());
            System.out.println("*************************************");
        }
        System.out.print("Pour changer le statut d'une intervention, entrez son numéro ou tapez # pour revenir au menu : ");
        String choix = scanner.nextLine();
        if (!choix.equals("#")) {
            try {
                int index = Integer.parseInt(choix) - 1;
                changerStatutIntervention(index);
            } catch (NumberFormatException | IndexOutOfBoundsException e) {
                System.out.println("Numéro invalide.");
            }
        }
    }

    // Méthode pour changer le statut d'une intervention
    private void changerStatutIntervention(int index) {
        Intervention intervention = interventions.get(index);
        System.out.println("Choisir le statut de l'intervention :");
        System.out.println("1. En cours");
        System.out.println("2. Terminé");
        System.out.print("Choix : ");
        int choix = scanner.nextInt();
        scanner.nextLine(); // Consommer la nouvelle ligne
        if (choix == 1) {
            intervention.setStatut("En cours");
        } else if (choix == 2) {
            intervention.setStatut("Terminé");
        } else {
            System.out.println("Choix invalide.");
            return;
        }
        sauvegarderDonnees();
        System.out.println("Statut de l'intervention mis à jour.");
    }

    // Méthode pour ajouter un nouveau client
    public void ajouterClient() {
        System.out.print("Nom : ");
        String nom = scanner.nextLine();
        System.out.print("Adresse : ");
        String adresse = scanner.nextLine();
        System.out.print("Numéro de téléphone : ");
        String numero = scanner.nextLine();
        Client client = new Client(nom, adresse, numero);
        clients.add(client);
        sauvegarderDonnees();
        System.out.println("Client ajouté avec succès.");
    }

    // Méthode pour ajouter un nouveau véhicule
    public void ajouterVehicule() {
        System.out.print("Marque : ");
        String marque = scanner.nextLine();
        System.out.print("Modèle : ");
        String modele = scanner.nextLine();
        System.out.print("Kilométrage : ");
        int kilometrage = scanner.nextInt();
        scanner.nextLine(); // Consommer la nouvelle ligne
        System.out.print("Immatriculation : ");
        String immatriculation = scanner.nextLine();

        System.out.println("Choisissez le propriétaire :");
        for (int i = 0; i < clients.size(); i++) {
            System.out.println((i + 1) + ". " + clients.get(i).getNom());
        }
        System.out.print("#. Créer un nouveau client\nChoix : ");
        String choix = scanner.nextLine();
        Client proprietaire;
        if (choix.equals("#")) {
            ajouterClient();
            proprietaire = clients.get(clients.size() - 1);
        } else {
            try {
                int index = Integer.parseInt(choix) - 1;
                proprietaire = clients.get(index);
            } catch (NumberFormatException | IndexOutOfBoundsException e) {
                System.out.println("Choix invalide.");
                return;
            }
        }

        Vehicule vehicule = new Vehicule(marque, modele, kilometrage, immatriculation, proprietaire);
        vehicules.add(vehicule);
        sauvegarderDonnees();
        System.out.println("Véhicule ajouté avec succès.");
    }

    // Méthode pour ajouter un mécanicien
    public void ajouterMecanicien() {
        System.out.print("Nom : ");
        String nom = scanner.nextLine();
        System.out.print("Matricule : ");
        String matricule = scanner.nextLine();
        Mecanicien mecanicien = new Mecanicien(nom, matricule);
        mecaniciens.add(mecanicien);
        sauvegarderDonnees();
        System.out.println("Mécanicien ajouté avec succès.");
    }

    // Méthode pour ajouter une intervention
    public void ajouterIntervention() {
        System.out.print("Description : ");
        String description = scanner.nextLine();
        System.out.print("Date de début (yyyy-MM-dd) : ");
        String dateDebut = scanner.nextLine();

        System.out.println("Choisissez un véhicule :");
        for (int i = 0; i < vehicules.size(); i++) {
            System.out.println((i + 1) + ". " + vehicules.get(i).getMarque() + " (Immatriculation : " + vehicules.get(i).getImmatriculation() + ")");
        }
        System.out.print("Choix : ");
        int choixVehicule = scanner.nextInt();
        scanner.nextLine(); // Consommer la nouvelle ligne
        Vehicule vehicule;
        try {
            vehicule = vehicules.get(choixVehicule - 1);
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Choix invalide.");
            return;
        }

        System.out.println("Choisissez un mécanicien :");
        for (int i = 0; i < mecaniciens.size(); i++) {
            System.out.println((i + 1) + ". " + mecaniciens.get(i).getNom());
        }
        System.out.print("Choix : ");
        int choixMecanicien = scanner.nextInt();
        scanner.nextLine(); // Consommer la nouvelle ligne
        Mecanicien mecanicien;
        try {
            mecanicien = mecaniciens.get(choixMecanicien - 1);
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Choix invalide.");
            return;
        }

        Intervention intervention = new Intervention(description, dateDebut, vehicule, mecanicien);
        interventions.add(intervention);
        sauvegarderDonnees();
        System.out.println("Intervention ajoutée avec succès.");
    }

    // Méthode pour rechercher un client par nom
    public void rechercherClient(String nom) {
        boolean trouve = false;
        for (Client client : clients) {
            if (client.getNom().equalsIgnoreCase(nom)) {
                System.out.println("Client trouvé : " + client);
                trouve = true;
                break;
            }
        }
        if (!trouve) {
            System.out.println("Client non trouvé.");
        }
    }

    // Méthode pour rechercher un véhicule par immatriculation
    public void rechercherVehicule(String immatriculation) {
        boolean trouve = false;
        for (Vehicule vehicule : vehicules) {
            if (vehicule.getImmatriculation().equalsIgnoreCase(immatriculation)) {
                System.out.println("Véhicule trouvé : " + vehicule);
                trouve = true;
                break;
            }
        }
        if (!trouve) {
            System.out.println("Véhicule non trouvé.");
        }
    }
}
