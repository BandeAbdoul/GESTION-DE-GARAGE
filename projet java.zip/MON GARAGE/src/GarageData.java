import java.io.Serializable;
import java.util.List;

public class GarageData implements Serializable {
    private List<Client> clients;
    private List<Vehicule> vehicules;
    private List<Mecanicien> mecaniciens;
    private List<Intervention> interventions;

    // Constructeur
    public GarageData(List<Client> clients, List<Vehicule> vehicules, List<Mecanicien> mecaniciens, List<Intervention> interventions) {
        this.clients = clients;
        this.vehicules = vehicules;
        this.mecaniciens = mecaniciens;
        this.interventions = interventions;
    }

    // Getters
    public List<Client> getClients() {
        return clients;
    }

    public List<Vehicule> getVehicules() {
        return vehicules;
    }

    public List<Mecanicien> getMecaniciens() {
        return mecaniciens;
    }

    public List<Intervention> getInterventions() {
        return interventions;
    }
}
